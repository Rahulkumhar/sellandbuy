import React, { Component } from 'react';
import {Row} from 'reactstrap';
import Header from './header';
import Footer from './Footer';
import CarouselComp from './main/casourel';
import AsideSearch from './main/asideSearch';
import ProductList from './main/productList';

class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
            <div>
                <Header search= "true"/>
               <div className="my-3 ">
               <CarouselComp />
               <Row className="container-fluid my-4">
                   <AsideSearch />
                   <ProductList />
               </Row>
               </div>
                <Footer/>
            </div>
         );
    }
}
 
export default Home;