import React, { Component } from "react";
import { Card, Button, CardTitle, CardText, Row, Col } from "reactstrap";

class ProductList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fav: false
    };
  }
  handleAddFavorite = () => {
    const { fav } = this.state;
    this.setState({
      fav: !fav
    });
  };
  render() {
    const { fav } = this.state;
    return (
      <React.Fragment>
        <div className="col-md-9">
          <Row className="mb-2">
            <Col sm="4">
              <Card body>
                <CardTitle>Special Title Treatment</CardTitle>
                <CardText>
                  {" "}
                  <img
                    className="d-block w-100"
                    src="../image/product1.webp"
                    alt="Third slide"
                    style={{ height: "100%" }}
                  />
                </CardText>
                <div>
                  <div className="d-flex justify-content-between">
                    <div>₹ 5,85,000</div>
                    <i
                      onClick={this.handleAddFavorite}
                      className={fav ? "fa fa-heart" : "fa fa-heart-o"}
                    />
                  </div>
                  <div>
                    <p> 2016- 70000km</p>
                  </div>
                  <div>
                    <p>Volkswagen Polo Comfortline 1.2L (D)</p>
                  </div>
                  <div className="d-flex justify-content-between small">
                    <div>Sector 28C, Chandigarh, Chandigarh</div>
                    <div>Apr 01</div>
                  </div>
                </div>
              </Card>
            </Col>
            <Col sm="4">
              <Card body>
                <CardTitle>Special Title Treatment</CardTitle>
                <CardText>
                  {" "}
                  <img
                    className="d-block w-100"
                    src="../image/product2.webp"
                    alt="Third slide"
                    style={{ height: "100%" }}
                  />
                </CardText>
                <div>
                  <div className="d-flex justify-content-between">
                    <div>₹ 40,31,182</div>
                    <i
                      onClick={this.handleAddFavorite}
                      className={fav ? "fa fa-heart" : "fa fa-heart-o"}
                    />
                  </div>
                  <div>
                   3 Bds - 2 Ba - 1236 ft2
                  </div>
                  <div>
                    <p> 3 BHK Flats for Sale in Labdhi Gardens Phase 6 at Neral, Mumbai</p>
                  </div>
                  <div className="d-flex justify-content-between small">
                    <div>Chirle Village, Navi Mumbai, Maharashtra</div>
                    <div>Apr 26</div>
                  </div>
                </div>
              </Card>
            </Col>
            <Col sm="4">
              <Card body>
                <CardTitle>Special Title Treatment</CardTitle>
                <CardText>
                  {" "}
                  <img
                    className="d-block w-100"
                    src="../image/product3.webp"
                    alt="Third slide"
                    style={{ height: "100%" }}
                  />
                </CardText>
                <div>
                  <div className="d-flex justify-content-between">
                    <div>₹ 449</div>
                    <i
                      onClick={this.handleAddFavorite}
                      className={fav ? "fa fa-heart" : "fa fa-heart-o"}
                    />
                  </div>
                  <div>
                    <p> Samsung. Mi. Oppo.vivo.lenovo.one plus.letv original charger availble</p>
                  </div>
                  <div>
                    <p>Volkswagen Polo Comfortline 1.2L (D)</p>
                  </div>
                  <div className="d-flex justify-content-between small">
                    <div>Chetpet, Chennai, Tamil Nadu</div>
                    <div>may 01</div>
                  </div>
                </div>
              </Card>
            </Col>
          </Row>
          <Row>
            <Col sm="4">
              <Card body>
                <CardTitle>Special Title Treatment</CardTitle>
                <CardText>
                  {" "}
                  <img
                    className="d-block w-100"
                    src="../image/product4.webp"
                    alt="Third slide"
                    style={{ height: "100%" }}
                  />
                </CardText>
                <div>
                  <div className="d-flex justify-content-between">
                    <div>₹ 18,000</div>
                    <i
                      onClick={this.handleAddFavorite}
                      className={fav ? "fa fa-heart" : "fa fa-heart-o"}
                    />
                  </div>
                  
                  <div>
                    <p>Brand new Samsung Galaxy watch 46mm with bill</p>
                  </div>
                  <div className="d-flex justify-content-between small">
                    <div>Marathahalli-Sarjapur Outer Ring Road, <br/>Bengaluru, Karnataka
                    </div>
                    <div>jan 10</div>
                  </div>
                </div>
              </Card>
            </Col>
            <Col sm="4">
              <Card body>
                <CardTitle>Special Title Treatment</CardTitle>
                <CardText>
                  {" "}
                  <img
                    className="d-block w-100"
                    src="../image/product5.webp"
                    alt="Third slide"
                    style={{ height: "100%" }}
                  />
                </CardText>
                <div>
                  <div className="d-flex justify-content-between">
                    <div>₹65,000</div>
                    <i
                      onClick={this.handleAddFavorite}
                      className={fav ? "fa fa-heart" : "fa fa-heart-o"}
                    />
                  </div>
                
                  <div>
                    <p>Note9 mob for sale</p>
                  </div>
                  <div className="d-flex justify-content-between small">
                    <div>Vinobanagara, Shivamogga, Karnataka</div>
                    <div>yesterdAY</div>
                  </div>
                </div>
              </Card>
            </Col>
            <Col sm="4">
              <Card body>
                <CardTitle>Special Title Treatment</CardTitle>
                <CardText>
                  {" "}
                  <img
                    className="d-block w-100"
                    src="../image/product6.webp"
                    alt="Third slide"
                    style={{ height: "100%" }}
                  />
                </CardText>
                <div>
                  <div className="d-flex justify-content-between">
                    <div>₹ 25,000</div>
                    <i
                      onClick={this.handleAddFavorite}
                      className={fav ? "fa fa-heart" : "fa fa-heart-o"}
                    />
                  </div>
                  
                  <div>
                    <p>Double decor bed</p>
                  </div>
                  <div className="d-flex justify-content-between small">
                    <div>Lingarajodi, Anugul, Odisha</div>
                    <div>july 12</div>
                  </div>
                </div>
              </Card>
            </Col>
          </Row>
        </div>
      </React.Fragment>
    );
  }
}

export default ProductList;
