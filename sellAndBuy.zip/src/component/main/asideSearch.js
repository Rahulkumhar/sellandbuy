import React, { Component } from 'react';

class AsideSearch extends Component {
    constructor(props) {
        super(props);
        this.state = {
             open:false 
            }
    }
    handleToggle =() => {
        const {open} = this.state
        this.setState({
        open:!open
        })
    }
    render() { 
        const { open} = this.state
        return ( 
           <React.Fragment>
            <div className="col-md-3">
                <strong>Filter</strong>
                <hr/>
                <div className="d-flex justify-content-between  ">
                    <div>
                        <h6>CATEGORIES</h6>
                        <div className="small">All Categories</div>
                      {open ?   <ul type="none" style={{marginLeft:"-27px"}}>
                            <li>Properties (332971)</li>
                            <li>Cars (490552)</li>
                            <li>Furniture (308734)</li>
                            <li>Jobs (210935)</li>
                            <li>Electronics & Appliances (555883)</li>
                            <li>Mobiles (683960)</li>
                            <li>Bikes (223504)</li>
                            <li>Books, Sports & Hobbies (122193)</li>
                            <li>Fashion (94434)</li>
                            <li>Pets (25902)</li>
                            <li>Services (90554)</li>
                        </ul> : ""}
                    </div>
                    <i onClick={this.handleToggle} className="fa fa-sort-desc"></i>
                </div>
                <hr/>
                <div className="d-flex justify-content-between  ">
                    <div>
                        <h6>LOCATIONS</h6>
                        <div className="small">India</div>
                        <ul type="none" style={{marginLeft:"-27px"}}>
                            <li>Maharashtra (466891)</li>
                            <li>Uttar Pradesh (286975)</li>
                            <li>Tamil Nadu (252300)</li>
                            <li>Karnataka (227485)</li>
                            <li>Delhi (224390)</li>
                            <span>View more</span>
                            <li>Kerala (210363)</li>
                            <li>Gujarat (185393)</li>
                            <li>Telangana (159624)</li>
                            <li>Punjab (142789)</li>
                            <li>West Bengal (137185)</li>
                            <span>View more</span>
                            <span>View all India</span>
                        </ul>
                    </div>
                    <i className="fa fa-sort-desc"></i>
                </div>
                <hr/>
                <div className="d-flex justify-content-between  ">
                    <div>
                        <h6>PRICE</h6>
                        <div className="small">All Categories</div>

                    </div>
                    <i className="fa fa-sort-desc"></i>
                </div>
            </div>
           </React.Fragment>
         );
    }
}
 
export default AsideSearch;