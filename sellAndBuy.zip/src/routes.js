import React, { Component } from 'react';
import {BrowserRouter, Route,} from 'react-router-dom';
import Login from './component/login';
import Register from './component/Register';
import Home from './component/home';


class Router extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return ( 
               <BrowserRouter>
                    <Route path="/" exact component= {Login} />                    
                    <Route path="/register" exact component= {Register} />                    
                    <Route path="/home" exact component= {Home} />                    
               </BrowserRouter>
         );
    }
}
 
export default Router;